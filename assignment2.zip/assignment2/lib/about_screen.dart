import 'package:flutter/material.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  final List<Map<String, String>> attractions = const [
    {
      'image':
      'https://dynamic-media-cdn.tripadvisor.com/media/photo-o/0f/30/78/2c/rama-meadows.jpg?w=500&h=400&s=1',
      'name': 'Deosai National Park'
    },
    {
      'image':
      'https://dynamic-media-cdn.tripadvisor.com/media/photo-o/0d/d5/1c/94/passu-valley-hunza-valley.jpg?w=500&h=400&s=1',
      'name': 'Hunza Valley'
    },
    {
      'image':
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ-W2noFs3CVIgM7WeB3QJ2lTc_-HWgnHBFLA&s',
      'name': 'k2 Peak'
    },
    {
      'image':
      'https://dynamic-media-cdn.tripadvisor.com/media/photo-o/19/de/45/a9/naran-is-a-small-town.jpg?w=600&h=600&s=1',
      'name': 'Naran'
    },
    {
      'image':
          'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSbXzLNhw1kIh1XMtkcsHmwoQfqZxQZwHaVrQ&s',
        'name': 'Ratti Gali Lake'
    },
    {
      'image':
          'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1m_gQ_dgVxUSB4oPru3cwPGVh3EvqK4iIYw&s',
     'name': 'Minar e Pakistan'
    },
  ];

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      padding: const EdgeInsets.all(10),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        childAspectRatio: 0.8,
      ),
      itemCount: attractions.length,
      itemBuilder: (context, index) {
        final place = attractions[index];
        return Card(
          elevation: 4,
          shape:
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: Column(
            children: [
              Expanded(
                child: ClipRRect(
                  borderRadius:
                   BorderRadius.vertical(top: Radius.circular(12)),
                  child: Image.network(
                    place['image']!,
                    fit: BoxFit.cover,
                    width: double.infinity,
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsets.all(8.0),
                child: Text(
                  place['name']!,
                  style:  TextStyle(
                      fontWeight: FontWeight.bold, color: Colors.blue),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
