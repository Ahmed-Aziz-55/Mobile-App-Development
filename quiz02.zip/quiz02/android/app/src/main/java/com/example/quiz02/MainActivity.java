package com.example.quiz02;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
