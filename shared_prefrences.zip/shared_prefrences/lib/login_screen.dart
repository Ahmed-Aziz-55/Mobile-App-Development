import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:shared_prefrences/home_screen.dart';
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final formData=GlobalKey<FormState>();
  final emailctrl= TextEditingController();
  final passctrl=TextEditingController();
  final agectrl=TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Shared preferences'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Form(
            key: formData,
              child:
              Column(
            children: [
              TextFormField(
                controller: emailctrl,
                decoration: InputDecoration(
                  hintText: 'Email',
                ),
                validator: (value){
                  if(value==null||value.isEmpty){
                    return 'Please Enter email';
                  }
                },
              ),
              SizedBox(
                height: 20,
              ),
              TextFormField(
                controller: passctrl,
                decoration: InputDecoration(
                  hintText: 'Password',

                ),
              ),
              SizedBox(
                height: 20,
              ),
              TextFormField(

                controller: agectrl,
                decoration: InputDecoration(
                  hintText: 'Age',

                ),
              ),
            ],
          ) ),
          SizedBox(
            height: 20,
          ),
          InkWell(
            onTap: () async {
              SharedPreferences sp= await SharedPreferences.getInstance();
              sp.setString('email', emailctrl.text);
              sp.setString('age', agectrl.text);
              sp.setBool('islogin', true);
              Navigator.push(context, MaterialPageRoute(builder: (context)=>HomeScreen()));
            },
            child: Container(
              height: 50,
              width: double.infinity,
              color: Colors.green,
              child: Center(
                child: Text('Click'),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
