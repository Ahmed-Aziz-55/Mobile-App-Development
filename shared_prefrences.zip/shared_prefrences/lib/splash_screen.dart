
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:shared_prefrences/home_screen.dart';
import 'package:shared_prefrences/login_screen.dart';
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {

  @override
    void initState() {
      super.initState();
      islogin();
    }
    void islogin() async{
     SharedPreferences sp= await SharedPreferences.getInstance();
     bool islogin=sp.getBool('isLogin') ?? false;
     if(islogin){
        Timer(Duration(seconds: 3),(){
         Navigator.push(context, MaterialPageRoute(builder: (context)=>HomeScreen()));
     });
     }
     else{
       Timer(Duration(seconds: 3),(){
       Navigator.push(context, MaterialPageRoute(builder: (context)=>LoginScreen()));
       }
       );
     }
    }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Center(
            child: Lottie.asset('assets/sandy_Loading.json'),
          )
        ],
      ),
    );
  }
}
