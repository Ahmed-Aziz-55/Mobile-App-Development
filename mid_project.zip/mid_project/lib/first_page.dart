import 'package:flutter/material.dart';
import 'package:mid_project/cart.dart';
class FirstPage extends StatelessWidget {
  const FirstPage({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          title: Text('Our Menu'),
          backgroundColor: Colors.white,
          actions: [
            Padding(
              padding: EdgeInsets.only(right: 10),
              child: IconButton(icon: Icon(Icons.shopping_cart_outlined),
                onPressed: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>Cart()));
                },
              ),
            ),
          ],
          bottom: TabBar(
            labelColor: Colors.deepOrange,
            indicatorColor: Colors.deepOrange,
            tabs: [
              Tab(text: 'Meals',),
              Tab(text: 'Sides',),
              Tab(text: 'Snacks',),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            // ********* Meals tab me GridView***************
            GridView.count(
              crossAxisCount: 2,
              childAspectRatio: 0.75,
              padding: EdgeInsets.all(10),
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
              children: [
                //********************* First food item*******************
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: Colors.grey.shade300),
                  ),
                  child: Column(
                    children: [
                      Padding(
                        padding:  EdgeInsets.symmetric(horizontal: 10),
                        child: CircleAvatar(
                          radius: 80,
                          backgroundImage: NetworkImage(
                              'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSXY4CKzbUCWis1NqTl6NEGFta6vmQBYumNpQ&s'),
                        ),
                      ),
                      Center(
                        child: Column(
                          children: [
                            Text('Spicy Noodles'),
                            Text('RS 500',
                                style: TextStyle(fontWeight: FontWeight.bold)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                //*****************************second food item*****************
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: Colors.grey.shade300),
                  ),
                  child: Column(
                    children: [
                      Padding(
                        padding:  EdgeInsets.symmetric(horizontal: 10),
                        child: CircleAvatar(
                          radius: 80,
                          backgroundImage: NetworkImage(
                              'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQtGxJQNLQ_tpfDqgGfFpEARarc7qNGTDVEYg&s'),
                        ),
                      ),
                      Column(
                        children: [
                          Text('Pasta'),
                          Text('Rs 400',
                              style: TextStyle(fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ],
                  ),
                ),
                // *************************third food item************************
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.grey.shade300),
                  ),
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        child: CircleAvatar(
                          radius: 80,
                          backgroundImage: NetworkImage(
                              'https://ministryofcurry.com/wp-content/uploads/2024/06/chicken-biryani-5.jpg'),
                        ),
                      ),
                      Center(child: Text('Chicken Biryani')),
                      Text('RS 300',
                          style: TextStyle(fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
                // fourth food item
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.grey.shade300),
                  ),
                  child: Column(
                    children: [
                      Padding(
                        padding:  EdgeInsets.symmetric(horizontal: 10),
                        child: CircleAvatar(
                          radius: 80,
                          backgroundImage: NetworkImage(
                              'https://www.tandoorihut.com.pk/wp-content/uploads/2021/04/Shinwari-Karahi.jpg'),
                        ),
                      ),
                      Center(child: Text('Shinwari Karahi')),
                      Text('RS 3000',
                          style: TextStyle(fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
                // *******************************fifth food item**************************
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.grey.shade300),
                  ),
                  child: Column(
                    children: [
                      Padding(
                        padding:  EdgeInsets.symmetric(horizontal: 10),
                        child: CircleAvatar(
                          radius: 80,
                          backgroundImage: NetworkImage(
                              'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSGh3gQqjqxo_-FNgKu-r9q7rGicucoxkksuw&s'),
                        ),
                      ),
                      Center(child: Text('Beef Pulao')),
                      Text('RS 550',
                          style: TextStyle(fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
                // ***************************sixth food item************************
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.grey.shade300),
                  ),
                  child: Column(
                    children: [
                      Padding(
                        padding:  EdgeInsets.symmetric(horizontal: 10),
                        child: CircleAvatar(
                          radius: 80,
                          backgroundImage: NetworkImage(
                              'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS0mkNvgBKVcWLgHUxleKosq6Qd5m8x5zMGJQ&s'),
                        ),
                      ),
                      Center(child: Text('Chicken Karahi')),
                      Text('RS 2000',
                          style: TextStyle(fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.grey.shade300),
                  ),
                  child: Column(
                    children: [
                      Padding(
                        padding:  EdgeInsets.symmetric(horizontal: 10),
                        child: CircleAvatar(
                          radius: 80,
                          backgroundImage: NetworkImage(
                              'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS0mkNvgBKVcWLgHUxleKosq6Qd5m8x5zMGJQ&s'),
                        ),
                      ),
                      Center(child: Text('Chicken Karahi')),
                      Text('RS 2000',
                          style: TextStyle(fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.grey.shade300),
                  ),
                  child: Column(
                    children: [
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 10),
                        child: CircleAvatar(
                          radius: 80,
                          backgroundImage: NetworkImage(
                              'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS0mkNvgBKVcWLgHUxleKosq6Qd5m8x5zMGJQ&s'),
                        ),
                      ),
                      Center(child: Text('Chicken Karahi')),
                      Text('RS 2000',
                          style: TextStyle(fontWeight: FontWeight.bold)),
                    ],

                  ),
                ),
              ],
            ),
            // *********************sides menu**********************************
            GridView.count(
              crossAxisCount: 2,
              padding: EdgeInsets.all(10),
              childAspectRatio: 0.7,
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              children: [
                //***********First Item*************************
                Stack(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadiusGeometry.circular(20),
                        border: Border.all(color: Colors.grey.shade300),
                      ),
                      child: Padding(
                        padding:  EdgeInsets.only(bottom:30,),
                        child: Center(
                          child: CircleAvatar(
                            radius: 80,
                            backgroundImage:  NetworkImage('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRMzhWNwlJW9C_a_YXR1K0VFhPVeJTq_AuXcgUzHYVPPebOs5hLLUgSSDjMC6Ba86tlhMU&usqp=CAU'),
                          ),
                        ),
                      ),
                    ),
                    Column(
                      children: [
                        Padding(
                          padding:  EdgeInsets.only(left: 135,top: 4),
                          child: Icon(Icons.favorite_outlined,
                            size: 20,
                            color: Colors.red,
                          ),
                        ),
                        Padding(
                          padding:  EdgeInsets.only(top: 155),
                          child: Column(
                            children: [
                              Center(child: Text('Melting Potatos')),
                            ],
                          ),
                        ),
                      ],
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 200),
                      child: Column(
                        children: [
                          Center(child: Text('RS 200',style: TextStyle(fontWeight: FontWeight.bold),)),
                        ],
                      ),
                    ),

                  ],
                ),
                //*******Second Item**********************
                Stack(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Colors.grey.shade300),
                      ),
                      child: Padding(
                        padding:  EdgeInsets.only(bottom: 30),
                        child: Center(
                          child: CircleAvatar(
                            radius: 80,
                            backgroundImage: NetworkImage('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQo3c64UGbnj6LihDjg28-EmIwX4JEavbQv9tRpk2aMFFAu6tsnFsYU5EKsLrbJSZHmYgk&usqp=CAU'),

                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 140,top: 8),
                      child: Column(
                        children: [
                          Icon(Icons.favorite_outline_sharp,
                            color: Colors.red,
                            size: 20,
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 185),
                      child: Column(
                        children: [
                          Center(child: Text('SALAD'),
                          ),
                          Padding(
                            padding: EdgeInsets.only(top: 4),
                            child: Column(
                              children: [
                                Text('RS 150',style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                //*******Third Item**********************
                Stack(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Colors.grey.shade300),
                      ),
                      child: Padding(
                        padding:  EdgeInsets.only(bottom: 30),
                        child: Center(
                          child: CircleAvatar(
                            radius: 80,
                            backgroundImage: NetworkImage('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR6_bfB8QVA3XjsUjam_BPXN07hnN1y1FiAnQ&s'),

                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding:  EdgeInsets.only(left: 140,top: 8),
                      child: Column(
                        children: [
                          Icon(Icons.favorite_outline_sharp,
                            color: Colors.red,
                            size: 20,
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding:  EdgeInsets.only(top: 185),
                      child: Column(
                        children: [
                          Center(child: Text('CornBread Salad'),
                          ),
                          Padding(
                            padding: EdgeInsets.only(top: 4),
                            child: Column(
                              children: [
                                Text('RS 1000',style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                //*******Fourth Item**********************
                Stack(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Colors.grey.shade300),
                      ),
                      child: Padding(
                        padding:  EdgeInsets.only(bottom: 30),
                        child: Center(
                          child: CircleAvatar(
                            radius: 80,
                            backgroundImage: NetworkImage('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQIdRDLshAfAilzobB6aiiHHippqrtOfX3MBw&s'),

                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 140,top: 8),
                      child: Column(
                        children: [
                          Icon(Icons.favorite_outline_sharp,
                            color: Colors.red,
                            size: 20,
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 185),
                      child: Column(
                        children: [
                          Center(child: Text('Chicken Mango Salad'),
                          ),
                          Padding(
                            padding:  EdgeInsets.only(top: 4),
                            child: Column(
                              children: [
                                Text('RS 300',style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                //*******5th Item**********************
                Stack(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Colors.grey.shade300),
                      ),
                      child: Padding(
                        padding:  EdgeInsets.only(bottom: 30),
                        child: Center(
                          child: CircleAvatar(
                            radius: 80,
                            backgroundImage: NetworkImage('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTWi5Gjp_0iHC2cLNWiGA3U-wBjtKuaRuPTeA&s'),

                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding:  EdgeInsets.only(left: 140,top: 8),
                      child: Column(
                        children: [
                          Icon(Icons.favorite_outline_sharp,
                            color: Colors.red,
                            size: 20,
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding:  EdgeInsets.only(top: 185),
                      child: Column(
                        children: [
                          Center(child: Text('Grilled Mushrooms'),
                          ),
                          Padding(
                            padding:  EdgeInsets.only(top: 4),
                            child: Column(
                              children: [
                                Text('RS 400',style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                //*******6th Item**********************
                Stack(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Colors.grey.shade300),
                      ),
                      child: Padding(
                        padding: EdgeInsets.only(bottom: 30),
                        child: Center(
                          child: CircleAvatar(
                            radius: 80,
                            backgroundImage: NetworkImage('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS3aHRu1kPq7ezw_zL82VIwrGHTSBXQEc-WVg&s'),

                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 140,top: 8),
                      child: Column(
                        children: [
                          Icon(Icons.favorite_outline_sharp,
                            color: Colors.red,
                            size: 20,
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding:  EdgeInsets.only(top: 185),
                      child: Column(
                        children: [
                          Center(child: Text('Pasta Salad'),
                          ),
                          Padding(
                            padding:  EdgeInsets.only(top: 4),
                            child: Column(
                              children: [
                                Text('RS 600',style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                //*******7th Item**********************
                Stack(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Colors.grey.shade300),
                      ),
                      child: Padding(
                        padding:EdgeInsets.only(bottom: 30),
                        child: Center(
                          child: CircleAvatar(
                            radius: 80,
                            backgroundImage: NetworkImage('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcROpuL4_jwYNPYFYPDgLwMR_wwf0Ewobph_nw&s'),

                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 140,top: 8),
                      child: Column(
                        children: [
                          Icon(Icons.favorite_outline_sharp,
                            color: Colors.red,
                            size: 20,
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 185),
                      child: Column(
                        children: [
                          Center(child: Text('Cowboy Butter'),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 4),
                            child: Column(
                              children: [
                                Text('RS 500',style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),

              ],
            ),
            //*********************Snacks Menu*************
            GridView.count(
              crossAxisCount: 2,
              padding: EdgeInsets.all(10),
              childAspectRatio: 0.7,
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              children: [
                //***********First Item*************************
                Stack(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadiusGeometry.circular(20),
                        border: Border.all(color: Colors.grey.shade300),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.only(bottom:30,),
                        child: Center(
                          child: CircleAvatar(
                            radius: 75,
                            backgroundImage:  NetworkImage('https://www.giallozafferano.com/images/277-27786/Potato-Chips_1200x800.jpg'),
                          ),
                        ),
                      ),
                    ),
                    Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 135,top: 4),
                          child: Icon(Icons.favorite_outlined,
                            size: 20,
                            color: Colors.red,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 160),
                          child: Column(
                            children: [
                              Center(child: Text('Melting Potatos')),
                            ],
                          ),
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 200),
                      child: Column(
                        children: [
                          Center(child: Text('RS 200',style: TextStyle(fontWeight: FontWeight.bold),)),
                        ],
                      ),
                    ),

                  ],
                ),
                //*******Second Item**********************
                Stack(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Colors.grey.shade300),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.only(bottom: 30),
                        child: Center(
                          child: CircleAvatar(
                            radius: 80,
                            backgroundImage: NetworkImage('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSXuMuKlfR4wbVEwNNnr5lAvPm1jxTpAG3g3g&s'),

                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 140,top: 8),
                      child: Column(
                        children: [
                          Icon(Icons.favorite_outline_sharp,
                            color: Colors.red,
                            size: 20,
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 185),
                      child: Column(
                        children: [
                          Center(child: Text('Samosa'),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 4),
                            child: Column(
                              children: [
                                Text('RS 50',style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                //*******Third Item**********************
                Stack(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Colors.grey.shade300),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.only(bottom: 30),
                        child: Center(
                          child: CircleAvatar(
                            radius: 75,
                            backgroundImage: NetworkImage('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTciPZex5V1tr0hwB0RHnNvczdON3K34aarJw&s'),

                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 140,top: 8),
                      child: Column(
                        children: [
                          Icon(Icons.favorite_outline_sharp,
                            color: Colors.red,
                            size: 20,
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 185),
                      child: Column(
                        children: [
                          Center(child: Text('Spring Roll'),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 4),
                            child: Column(
                              children: [
                                Text('RS 100',style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                //*******Fourth Item**********************
                Stack(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Colors.grey.shade300),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.only(bottom: 30),
                        child: Center(
                          child: CircleAvatar(
                            radius: 80,
                            backgroundImage: NetworkImage('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQtbO0pWgOAIMcF89AEutxg822W74k6Jx8Hnw&s'),
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 140,top: 8),
                      child: Column(
                        children: [
                          Icon(Icons.favorite_outline_sharp,
                            color: Colors.red,
                            size: 20,
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 185),
                      child: Column(
                        children: [
                          Center(child: Text('Grilled Sandwich'),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 4),
                            child: Column(
                              children: [
                                Text('RS 300',style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                //*******5th Item**********************
                Stack(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Colors.grey.shade300),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.only(bottom: 30),
                        child: Center(
                          child: CircleAvatar(
                            radius: 75,
                            backgroundImage: NetworkImage('https://hips.hearstapps.com/hmg-prod/images/glazed-donut-recipe-1-65008ab2b45fb.jpg?crop=0.75xw:1xh;center,top&resize=1200:*'),

                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 140,top: 8),
                      child: Column(
                        children: [
                          Icon(Icons.favorite_outline_sharp,
                            color: Colors.red,
                            size: 20,
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 185),
                      child: Column(
                        children: [
                          Center(child: Text('Donut'),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 4),
                            child: Column(
                              children: [
                                Text('RS 150',style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                //*******6th Item**********************
                Stack(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Colors.grey.shade300),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.only(bottom: 30),
                        child: Center(
                          child: CircleAvatar(
                            radius: 75,
                            backgroundImage: NetworkImage('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSGG1UjGPEIUz70x1y0JJZYig2I7acjAdwH3g&s'),

                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 140,top: 8),
                      child: Column(
                        children: [
                          Icon(Icons.favorite_outline_sharp,
                            color: Colors.red,
                            size: 20,
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 185),
                      child: Column(
                        children: [
                          Center(child: Text('Samosa Chaat'),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 4),
                            child: Column(
                              children: [
                                Text('RS 200',style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                //*******7th Item**********************
                Stack(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Colors.grey.shade300),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.only(bottom: 30),
                        child: Center(
                          child: CircleAvatar(
                            radius: 75,
                            backgroundImage: NetworkImage('https://sausagemaker.com/wp-content/uploads/Homemade-French-Fries_8.jpg'),

                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 140,top: 8),
                      child: Column(
                        children: [
                          Icon(Icons.favorite_outline_sharp,
                            color: Colors.red,
                            size: 20,
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 185),
                      child: Column(
                        children: [
                          Center(child: Text('French Fries'),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 4),
                            child: Column(
                              children: [
                                Text('RS 100',style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),

              ],
            ),
          ],
        ),
      ),
    );
  }
}

