package com.example.bidding_page;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
